Sanity Tests » docs-build
=========================

Verifies that ``make singlehtmldocs`` in ``docs/docsite/`` completes without errors.
